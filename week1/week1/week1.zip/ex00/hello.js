console.log("Hello JS!");
